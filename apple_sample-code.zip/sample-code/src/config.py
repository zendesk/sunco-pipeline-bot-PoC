# Copyright 2016-2021 Apple, Inc.
# All Rights Reserved.

AMB_SERVER = "https://mspgw.push.apple.com/v1"

MSP_ID = "<your-csp-id>"
BIZ_ID = "<a-unique-business-id>"

SECRET = "<the secret passphrase for API>"

IMESSAGE_EXTENSION_BID = "com.apple.messages.MSMessageExtensionBalloonPlugin:0000000000:com.apple.icloud.apps.messages.business.extension"
