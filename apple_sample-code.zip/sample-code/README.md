# messages-for-business-msp-tutorial
Apple Messages for Business MSP (Messaging Service Provider) Tutorial

Hello there. These are the code samples for the step-by-step tutorial to integrate the features of Apple Messages for Business (AMB, formerly known as Business Chat) into a Messaging Service Provider (MSP) platform. These require use of the AMB application programming interface (API) which is detailed here 

We provide these code examples written in the Python programming language. Python is the easiest to read major programming language and close to the pseudo-code often used in computer science textbooks. Python is also available and accessible across many platforms. For these reasons, we chose Python for the code samples. The fundamental architecture of AMB API is based on the HTTP protocol, though. Our features can be implemented in any programming language.

You will need a recent version of the Python3 interpretor. You will need to use `pip` or similar tool to install the following Python libraries:

cryptography
Flask
pycryptodome
pyjwt
requests


Files and directories of interest in this repo:

>/samples has a number of example JSON payloads referenced throughout the tutorial
>/src is the directory for code samples
>/templates has the html template needed for the client landing page exercise
>attachment_cipher.py has the encode() and decode() methods needed for sending and receiving attachments and other files
>auth_util.py contains a class and several methods for implementing the OAuth2 authorization exercises
>config.py contains the constants for your instance. Replace the values with the appropriate values for your environment
>jwt_util.py has a method used for generating the Javascript Web Token (JWT) used for signing messages

Enjoy!
